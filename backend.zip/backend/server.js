require('dotenv').config();
const express = require('express');
const connectDB = require('./config/db');
const { erroeHandler } = require('./middleware/errormiddleware');
const routes = require('./routes/routes');

const app = express();
connectDB();

app.use(express.json());

//routes
app.use('/api', routes);

const PORT = 5000;
app.listen(PORT, () => console.log(`server running on port ${PORT}`));