import React, {usestate} from "react";
import axios from "axios";

function login() {
    const[formData, setformData] = usestate({
        email: "",
        password: ""
    })
    const handleChange = (e) => {
        setformData({...formData, [e.target.name]:e.target.value});
    };
    const handleSubmit = (e) => {
        e.preventDefault();

        try {
            const res = await axios.post(

                formData
            );
            alert(res.data.message)
            console.log(res.data)
        } catch(error) {
            alert(error.response?.data?.message || "Login failed");
        }
    }
}