const mongoose = require('mongoose')

const order = new mongoose.Schema({
    id:{type: String, required: true},
    items:{type: String, required: true},
    farmer:{type: String, required: true},
    total:{type: Number, required: true},
    steps:{type: Number, required: true},
    status:{type: String, required: true}
});

const Orders = mongoose.model("Orders",order);

module.exports = Orders;